AOS.init({
    offset: 120, 
    delay: 0, 
    duration: 900, 
    easing: 'ease', 
    once: false, 
    mirror: false, 
    anchorPlacement: 'top-bottom', 
  });

    function showProductInfo(name, price) {
        alert(`Product: ${name}\nPrice: ${price}`);
    }
    document.addEventListener("DOMContentLoaded", function() {
        window.addEventListener('scroll', function() {
            var scrollDistance = window.scrollY;
    
            // Iterate through sections to find which one is active
            document.querySelectorAll('.section-padding').forEach(function (section, index) {
                if (section.offsetTop <= scrollDistance && 
                    section.offsetTop + section.offsetHeight > scrollDistance) {
                    document.querySelectorAll('.navbar-nav .nav-link').forEach(function (link) {
                        link.classList.remove('active');
                    });
                    document.querySelectorAll('.navbar-nav .nav-link')[index].classList.add('active');
                }
            });
        });
    });